Name: Andrew Land (aml136 - PS# 3688776)
Email: aml136@pitt.edu
Recitation: Friday 2:00-2:50pm
