Name: Anrew Land (aml136 - PS# 3688776)
Recitation: Friday 2:00-2:50pm
Project Due: 9-10-13
Handed In: 9-10-13
Source Code:
  assignment1.java
Compiled Files:
  assignment1.class
  also contains author provided .class files
Other:
  theprice.txt
  mobydick.txt
  merchant.txt
  dickens.txt
  warandpeace.txt
Compilation Instructions:
  javac assignment1.java
Opperation:
  java assignment1 [filename1] [filename 2]
