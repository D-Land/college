/*
 *
 *     Author: Andrew Land
 *      Email: aml136#pitt.edu
 *        PS#: 3688776
 *       Date: 9/24/13
 * Assignment: 2
 *
 */

public class ParseError extends Exception{
  //Prints the String of the error
  public ParseError(String error){
    super(error);
  }
}

