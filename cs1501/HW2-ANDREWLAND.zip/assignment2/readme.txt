Name: Andrew Land (aml136 - PS# 3688776)
Email: aml136@pitt.edu
Recitation: Friday 2:00-2:50pm
Project Due: 9-24-13
Handed In: 9-24-13
Source Code:
  Expression.java
  ExpressionEvaluator.java
  ExpressionDisplayer.java
  ParseError.java
  Node.java
Compiled Files:
  Expression.class
  ExpressionEvaluator.class
  ExpressionDisplayer.class
  ParseError.class
  Node.class
  TreeDisplay.class
Other:
Compilation Instructions:
  javac *.java
Opperation:
  java ExpressionEvaluator data2eval.txt
  java ExpressionDisplayer data.txt
